from Disease_data import Diseases
import random
import string
import csv
from datetime import date

def generate_patient_id():
    patient_id = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
    return patient_id

def get_patient_details():
    patient_id = generate_patient_id()
    name = input("Enter your name: ")
    today = date.today()
    age = int(input("Enter your age: "))
    gender = input("Enter your gender (M/F): ")
    height = float(input("Enter your height (in meters): "))
    weight = float(input("Enter your weight (in kilograms): "))
    return patient_id, name, today, age, gender, height, weight

def display_disease_list():
    print("Select a disease from the following list:")
    for i, disease in enumerate(Diseases, 1):
        print(f"{i}. {disease['name']}")

def get_disease_choice():
    choice = int(input("Enter the number corresponding to your disease: "))
    return Diseases[choice - 1]

def check_symptoms(disease):
    print(f"Symptoms of {disease['name']}:")
    for symptom in disease['symptoms']:
        print(f"- {symptom}")
    user_input = input("Do you experience any of these symptoms? (yes/no): ")
    return user_input.lower() == "yes"

def prescribe_treatment(disease, patient_data):
    if check_symptoms(disease):
        print(f"\nReasons for {disease['name']}:")
        for reason in disease['reasons']:
            print(f"- {reason}")
        print(f"\nPrevention methods for {disease['name']}:")
        for prevention in disease['prevention']:
            print(f"- {prevention}")
        print("\nRecommended medications:")
        for medication in disease['medications']:
            print(f"- {medication}")
        save_patient_data(patient_data, disease)
    else:
        print("You do not seem to have the symptoms of this disease.")

def save_patient_data(patient_data, disease):
    patient_id, name, date, age, gender, height, weight = patient_data
    symptoms = ', '.join(disease['symptoms'])
    reasons = ', '.join(disease['reasons'])
    medications = ', '.join(disease['medications'])
    with open('D:\\c\\patient_data.csv','a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([patient_id, name, date, age, gender, height, weight, disease['name'], symptoms, reasons, medications])

def get_patient_history(patient_id):
    with open('D:\\c\\patient_data.csv','r') as csvfile:
        reader = csv.reader(csvfile)
        patient_history = [row for row in reader if row[0] == patient_id]
    if patient_history:
        print(f"Patient History for {patient_id}:")
        for row in patient_history:
            print(f"Date: {row[2]}, Disease: {row[7]}, Symptoms: {row[8]}, Reasons: {row[9]}, Medications: {row[10]}")
    else:
        print(f"No patient history found for {patient_id}")

print("Welcome to the HealthBot!")
print("How can I assist you today? ")
def main():
    patient_id, name, today, age, gender, height, weight = get_patient_details()
    patient_data = (patient_id, name, today, age, gender, height, weight)
    display_disease_list()
    disease = get_disease_choice()
    prescribe_treatment(disease, patient_data)
    get_patient_history_choice = input("Do you want to get your patient history? (yes/no): ").lower()
    if get_patient_history_choice == "yes":
        get_patient_history(patient_id)

if __name__ == "__main__":
    main()

