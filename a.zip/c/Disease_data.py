Diseases =[
    {
        "name": "Headache",
        "symptoms": [
            "A dull, aching pain",
            "tightness or pressure across the forehead ",
            "tightness around neck and scalp"
        ],
        "medications": [
            "aspirin",
            "naproxen",
        ],
        "reasons": [
            "Changes in weather",
            "Skipping meals",
            "Irregular sleep habits",
        ],
        "prevention": [
            "Be aware of early symptoms",
            "Maintain regular schedules",
        ],
    },
    {
        "name": "Stomach Aches",
        "symptoms": [
            "pain in the upper abdomen",
        ],
        "medications": [
            "loperamide",
            "bismuth subsalicylate",
        ],
         "reasons": [
            "Eating or drinking rapidly",
            "Drinking through a straw",
        ],
        "prevention": [
            "Eat slowly",
            "chew your food thoroughly",
            "Eat several small meals throughout the day",
        ],
    },
      {
        "name": "Nausea and Vomiting",
        "symptoms": [
            "Lack of appetite",
            "Feeling like you are about to vomit",
        ],
        "medications": [
            "haloperidol",
            "Chlorpromazine",
            "perphenazine",
        ],
         "reasons": [
            "Motion sickness",
            "Eating too much or eating spoiled food",
        ],
        "prevention": [
            "Don’t eat solid foods",
            " Don’t drink milk.",
        ],
    },
    {
        "name": "Diarrhea",
        "symptoms": [
            "Stomach pain",
            "Swelling (bloating)",
        ],
        "medications": [
            "loperamide link",
            "bismuth subsalicylate link",
        ],
         "reasons": [
            "Viral infection",
            "Food intolerance",
        ],
        "prevention": [
            "Avoid high sugar drinks",
            "Decrease level of exercise",
        ],
    },
    {
        "name": "Cold and Flu",
        "symptoms": [
            "Cough",
            "Sore throat",
        ],
        "medications": [
            "Antihistamines",
        ],
         "reasons": [
            "change in weather",
            "Most transmission of  viruses",
        ],
        "prevention": [
            "Drink lots of clear fluids ",
            "Stay away from cigarette smoke",
        ],
    },
    {
        "name": "Allergies",
        "symptoms": [
            "Sneezing",
            "Runny nose",
        ],
        "medications": [
            "Cetirizine",
        ],
         "reasons": [
            "foods (nuts, eggs, milk, soy, shellfish, wheat)",
            "pollen",
        ],
        "prevention": [
            "avoid going outdoors during weather change",
            "wear full sleves",
        ],
    },
]
